-- KHANZA PORTFOLIO SUPABASE SCHEMA
create extension if not exists "pgcrypto";

create table if not exists public.profiles (
 id uuid primary key default gen_random_uuid(), brand_name text not null default 'Khanza', brand_mark text not null default 'K',
 hero_accent text not null default 'Athaa', hero_line2 text not null default 'siswa yang suka', hero_line3 text not null default 'berkreasi & ceria.',
 hero_lead text not null default '', email text not null default '', legal_name text not null default '', footer_credit text not null default '',
 created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.about (
 id uuid primary key default gen_random_uuid(), hi text not null default '', heading text not null default '', p1 text not null default '', p2 text not null default '',
 fact_name text not null default '', fact_status text not null default '', fact_location text not null default '', fact_interest text not null default '', quote_author text not null default '',
 created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.activities (
 id uuid primary key default gen_random_uuid(), role text not null default '', title text not null default '', org text not null default '', description text not null default '', period text not null default '',
 sort_order integer not null default 0, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.education (
 id uuid primary key default gen_random_uuid(), year text not null default '', school text not null default '', location text not null default '', description text not null default '',
 tags jsonb not null default '[]'::jsonb, sort_order integer not null default 0, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.achievements (
 id uuid primary key default gen_random_uuid(), icon text not null default '', title text not null default '', subtitle text not null default '',
 sort_order integer not null default 0, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.skills (
 id uuid primary key default gen_random_uuid(), icon text not null default '', title text not null default '', subtitle text not null default '',
 sort_order integer not null default 0, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.projects (
 id uuid primary key default gen_random_uuid(), emoji text not null default '', tag text not null default '', title text not null default '', description text not null default '',
 tags jsonb not null default '[]'::jsonb, link text not null default '', sort_order integer not null default 0, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.socials (
 id uuid primary key default gen_random_uuid(), social_key text not null unique, label text not null default '', url text not null default '',
 sort_order integer not null default 0, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table if not exists public.photos (
 id uuid primary key default gen_random_uuid(), photo_type text not null check(photo_type in ('profile','activity')),
 activity_id uuid null references public.activities(id) on delete cascade, storage_path text not null, public_url text not null, caption text not null default '',
 sort_order integer not null default 0, created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 constraint photos_activity_required check((photo_type='activity' and activity_id is not null) or (photo_type='profile' and activity_id is null)));

create or replace function public.set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at=now(); return new; end; $$;

do $$
declare t text;
begin
 for t in select unnest(array['profiles','about','activities','education','achievements','skills','projects','socials','photos']) loop
   execute format('drop trigger if exists updated_at on public.%I',t);
   execute format('create trigger updated_at before update on public.%I for each row execute function public.set_updated_at()',t);
 end loop;
end $$;

alter table public.profiles enable row level security;
alter table public.about enable row level security;
alter table public.activities enable row level security;
alter table public.education enable row level security;
alter table public.achievements enable row level security;
alter table public.skills enable row level security;
alter table public.projects enable row level security;
alter table public.socials enable row level security;
alter table public.photos enable row level security;

create or replace function public.is_portfolio_admin() returns boolean language sql stable security definer set search_path=public as $$
select auth.uid()='0f793c54-458e-4dc1-b674-ab9f63b70388'::uuid;
$$;

do $$
declare t text;
begin
 for t in select unnest(array['profiles','about','activities','education','achievements','skills','projects','socials','photos']) loop
   execute format('drop policy if exists "public read" on public.%I',t);
   execute format('create policy "public read" on public.%I for select to anon,authenticated using(true)',t);
   execute format('drop policy if exists "admin insert" on public.%I',t);
   execute format('create policy "admin insert" on public.%I for insert to authenticated with check(public.is_portfolio_admin())',t);
   execute format('drop policy if exists "admin update" on public.%I',t);
   execute format('create policy "admin update" on public.%I for update to authenticated using(public.is_portfolio_admin()) with check(public.is_portfolio_admin())',t);
   execute format('drop policy if exists "admin delete" on public.%I',t);
   execute format('create policy "admin delete" on public.%I for delete to authenticated using(public.is_portfolio_admin())',t);
 end loop;
end $$;

insert into public.socials(social_key,label,url,sort_order) values
('instagram','Instagram','',1),('github','GitHub','',2),('linkedin','LinkedIn','',3),('twitter','Twitter','',4),('dribbble','Dribbble','',5)
on conflict(social_key) do nothing;

drop policy if exists "admin upload portfolio photos" on storage.objects;
create policy "admin upload portfolio photos" on storage.objects for insert to authenticated
with check(bucket_id='portfolio-photos' and public.is_portfolio_admin());
drop policy if exists "admin update portfolio photos" on storage.objects;
create policy "admin update portfolio photos" on storage.objects for update to authenticated
using(bucket_id='portfolio-photos' and public.is_portfolio_admin())
with check(bucket_id='portfolio-photos' and public.is_portfolio_admin());
drop policy if exists "admin delete portfolio photos" on storage.objects;
create policy "admin delete portfolio photos" on storage.objects for delete to authenticated
using(bucket_id='portfolio-photos' and public.is_portfolio_admin());
