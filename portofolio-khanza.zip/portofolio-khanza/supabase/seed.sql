-- KHANZA PORTFOLIO INITIAL SEED
-- Run once after schema. Safe: each row is inserted only if the matching content is absent.

insert into public.profiles (brand_name,brand_mark,hero_accent,hero_line2,hero_line3,hero_lead,email,legal_name,footer_credit)
select 'Khanza','K','Athaa','siswa yang suka','berkreasi & ceria.','Seorang siswi yang passionate di bidang desain, teknologi, dan kegiatan organisasi. Suka belajar hal baru, bikin karya yang meaningful, dan tumbuh bareng komunitas.','athaa.maharani@email.com','Khanza Zhafira Putri Askalani','Dibuat dengan ♥ & banyak kopi (sama teh) ☕'
where not exists(select 1 from public.profiles);

insert into public.about (hi,heading,p1,p2,fact_name,fact_status,fact_location,fact_interest,quote_author)
select 'Hi there! ☁️','Pelajar yang suka hal-hal kecil yang indah.','Hai! Namaku Khanza. Saat ini aku masih duduk di bangku sekolah dan aktif di berbagai kegiatan organisasi. Bagiku, sekolah bukan cuma soal nilai — tapi juga soal pengalaman, relasi, dan karya yang bisa dibanggain.','Di waktu luang, aku suka desain, ngulik hal-hal baru soal teknologi, nulis di jurnal, dan jalan-jalan cari inspiraaasi ✨','Athaa Maharani','Pelajar SMA','Jakarta, ID','Desain & Tech','Khanza'
where not exists(select 1 from public.about);

insert into public.activities(role,title,org,description,period,sort_order)
select 'OSIS','Koordinator Divisi Acara','OSIS SMA Negeri 1 Contoh Kota','Mengkoordinasi pelaksanaan acara sekolah, mulai dari planning, budgeting, sampai eksekusi hari-H. Belajar jadi leader yang dengerin tim.','2024 — Sekarang',1
where not exists(select 1 from public.activities where title='Koordinator Divisi Acara');

insert into public.activities(role,title,org,description,period,sort_order)
select 'Ekstrakurikuler','Anggota English Club','English Club SMA Negeri 1 Contoh Kota','Latihan public speaking, debat, dan storytelling dalam bahasa Inggris. Pernah mewakili sekolah di lomba speech tingkat kota.','2023 — Sekarang',2
where not exists(select 1 from public.activities where title='Anggota English Club');

insert into public.activities(role,title,org,description,period,sort_order)
select 'Volunteer','Relawan Komunitas Hijau','Komunitas Hijau Jakarta','Ikut kegiatan bersih-bersih kota, kampanye lingkungan, dan workshop daur ulang untuk anak-anak. Suka banget karena bisa kontribusi langsung.','2024 — Sekarang',3
where not exists(select 1 from public.activities where title='Relawan Komunitas Hijau');

insert into public.activities(role,title,org,description,period,sort_order)
select 'Design Team','Tim Kreatif Sekolah','Media & Publikasi Sekolah','Bikin feeds Instagram sekolah, poster acara, dan desain merchandise. Tempat pertama kali belajar bahwa desain itu powerful.','2023 — Sekarang',4
where not exists(select 1 from public.activities where title='Tim Kreatif Sekolah');

insert into public.activities(role,title,org,description,period,sort_order)
select 'Workshop','Panitia Workshop Desain','Youth Creative Festival 2024','Panitia sekaligus MC di workshop desain grafis untuk pelajar. Ngajarin basic Canva dan Figma ke temen-temen yang baru mulai.','2024',5
where not exists(select 1 from public.activities where title='Panitia Workshop Desain');

insert into public.activities(role,title,org,description,period,sort_order)
select 'Komunitas','Anggota Pelajar.id','Komunitas Pelajar.id','Komunitas online pelajar se-Indonesia. Tempat sharing project, ikutan challenge mingguan, dan dapat teman baru dari berbagai kota.','2024 — Sekarang',6
where not exists(select 1 from public.activities where title='Anggota Pelajar.id');

insert into public.education(year,school,location,description,tags,sort_order)
select '2023 — Sekarang','SMA Negeri 1 Contoh Kota','Jakarta · Jurusan IPA','Fokus di mata pelajaran sains dan aktif mengikuti ekstrakurikuler. Aktif di OSIS sebagai koordinator divisi acara dan menjadi mentor untuk adik kelas.','["Matematika", "Fisika", "Bahasa Inggris", "Informatika"]'::jsonb,1
where not exists(select 1 from public.education where school='SMA Negeri 1 Contoh Kota');

insert into public.education(year,school,location,description,tags,sort_order)
select '2020 — 2023','SMP Negeri 5 Contoh Kota','Jakarta','Awal mula ketertarikan di bidang desain dan komputer. Mulai belajar Canva, bikin poster kelas, dan aktif di English Club.','["Juara 2 Poster Kelas", "English Club", "Pramuka"]'::jsonb,2
where not exists(select 1 from public.education where school='SMP Negeri 5 Contoh Kota');

insert into public.achievements(icon,title,subtitle,sort_order)
select 'medal','Juara 2 Lomba Poster','Tingkat kota — tahun 2023',1
where not exists(select 1 from public.achievements where title='Juara 2 Lomba Poster');

insert into public.achievements(icon,title,subtitle,sort_order)
select 'star','Finalis Speech Contest','Sekolah — tahun 2024',2
where not exists(select 1 from public.achievements where title='Finalis Speech Contest');

insert into public.achievements(icon,title,subtitle,sort_order)
select 'user','MC Upacara & Acara','Lebih dari 5 event sekolah',3
where not exists(select 1 from public.achievements where title='MC Upacara & Acara');

insert into public.achievements(icon,title,subtitle,sort_order)
select 'file','Sertifikasi Desain Grafis','Pelajar.id Bootcamp 2024',4
where not exists(select 1 from public.achievements where title='Sertifikasi Desain Grafis');

insert into public.achievements(icon,title,subtitle,sort_order)
select 'home','Ketua Kelas 3 Tahun Berturut','SMP & SMA',5
where not exists(select 1 from public.achievements where title='Ketua Kelas 3 Tahun Berturut');

insert into public.achievements(icon,title,subtitle,sort_order)
select 'globe','Aktif di 4 Komunitas','Sekolah & komunitas online',6
where not exists(select 1 from public.achievements where title='Aktif di 4 Komunitas');

insert into public.skills(icon,title,subtitle,sort_order)
select 'design','UI / UX Design','Figma, Canva, design system',1
where not exists(select 1 from public.skills where title='UI / UX Design');

insert into public.skills(icon,title,subtitle,sort_order)
select 'code','Front-End Dev','HTML, CSS, JavaScript basics',2
where not exists(select 1 from public.skills where title='Front-End Dev');

insert into public.skills(icon,title,subtitle,sort_order)
select 'speaking','Public Speaking','Presentasi & MC acara',3
where not exists(select 1 from public.skills where title='Public Speaking');

insert into public.skills(icon,title,subtitle,sort_order)
select 'leadership','Leadership','Mengelola tim & event',4
where not exists(select 1 from public.skills where title='Leadership');

insert into public.skills(icon,title,subtitle,sort_order)
select 'writing','Content Writing','Copywriting & journaling',5
where not exists(select 1 from public.skills where title='Content Writing');

insert into public.skills(icon,title,subtitle,sort_order)
select 'visual','Visual Design','Canva, ilustrasi, branding',6
where not exists(select 1 from public.skills where title='Visual Design');

insert into public.skills(icon,title,subtitle,sort_order)
select 'chat','Komunikasi','Asik & mudah dipahami',7
where not exists(select 1 from public.skills where title='Komunikasi');

insert into public.skills(icon,title,subtitle,sort_order)
select 'clock','Time Management','Produktif & terorganisir',8
where not exists(select 1 from public.skills where title='Time Management');

insert into public.projects(emoji,tag,title,description,tags,link,sort_order)
select '📔','UI/UX','Aplikasi Jurnal Harian','Konsep aplikasi journaling buat pelajar dengan mood tracker dan reminder menulis setiap malam.','["Figma", "UX Research", "Prototype"]'::jsonb,'',1
where not exists(select 1 from public.projects where title='Aplikasi Jurnal Harian');

insert into public.projects(emoji,tag,title,description,tags,link,sort_order)
select '🎨','Branding','Branding Class Festival','Identity design untuk festival kelas — logo, poster, feed IG, sampai merchandise. Tema: pastel cute aesthetic.','["Canva", "Logo", "Poster"]'::jsonb,'',2
where not exists(select 1 from public.projects where title='Branding Class Festival');

insert into public.projects(emoji,tag,title,description,tags,link,sort_order)
select '🌱','Campaign','Kampanye "Hijaukan Sekolah"','Konsep kampanye lingkungan dengan poster, konten IG, dan video pendek ajak siswa peduli sampah plastik.','["Design", "Content", "Video"]'::jsonb,'',3
where not exists(select 1 from public.projects where title='Kampanye "Hijaukan Sekolah"');

insert into public.projects(emoji,tag,title,description,tags,link,sort_order)
select '💌','Web','Web Surat untuk Guru','Mini web interaktif berisi surat digital ucapan dari siswa ke guru saat hari guru. Dibuat pakai HTML & CSS.','["HTML", "CSS", "Animation"]'::jsonb,'',4
where not exists(select 1 from public.projects where title='Web Surat untuk Guru');
