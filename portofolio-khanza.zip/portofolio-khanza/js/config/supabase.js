// Supabase public client configuration.
// Publishable/anon keys are intended for browser use. NEVER put a service_role/secret key here.
export const SUPABASE_URL = 'https://ssgsfqmrpukteexeplmf.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_58_Fdo8Y61F3tfLaAPpvXQ_zno-nf3A';
