export const defaultData = {
  "config": {
    "password": "khanza"
  },
  "profile": {
    "brandName": "Khanza",
    "brandMark": "K",
    "heroAccent": "Athaa",
    "heroLine2": "siswa yang suka",
    "heroLine3": "berkreasi & ceria.",
    "heroLead": "Seorang siswi yang passionate di bidang desain, teknologi, dan kegiatan organisasi. Suka belajar hal baru, bikin karya yang meaningful, dan tumbuh bareng komunitas.",
    "email": "athaa.maharani@email.com",
    "photos": [],
    "legalName": "Khanza Zhafira Putri Askalani",
    "footerCredit": "Dibuat dengan ♥ & banyak kopi (sama teh) ☕"
  },
  "about": {
    "hi": "Hi there! ☁️",
    "heading": "Pelajar yang suka hal-hal kecil yang indah.",
    "p1": "Hai! Namaku Khanza. Saat ini aku masih duduk di bangku sekolah dan aktif di berbagai kegiatan organisasi. Bagiku, sekolah bukan cuma soal nilai — tapi juga soal pengalaman, relasi, dan karya yang bisa dibanggain.",
    "p2": "Di waktu luang, aku suka desain, ngulik hal-hal baru soal teknologi, nulis di jurnal, dan jalan-jalan cari inspiraaasi ✨",
    "factName": "Athaa Maharani",
    "factStatus": "Pelajar SMA",
    "factLocation": "Jakarta, ID",
    "factInterest": "Desain & Tech",
    "quoteAuthor": "Khanza"
  },
  "activities": [
    {
      "role": "OSIS",
      "title": "Koordinator Divisi Acara",
      "org": "OSIS SMA Negeri 1 Contoh Kota",
      "desc": "Mengkoordinasi pelaksanaan acara sekolah, mulai dari planning, budgeting, sampai eksekusi hari-H. Belajar jadi leader yang dengerin tim.",
      "period": "2024 — Sekarang",
      "photos": []
    },
    {
      "role": "Ekstrakurikuler",
      "title": "Anggota English Club",
      "org": "English Club SMA Negeri 1 Contoh Kota",
      "desc": "Latihan public speaking, debat, dan storytelling dalam bahasa Inggris. Pernah mewakili sekolah di lomba speech tingkat kota.",
      "period": "2023 — Sekarang",
      "photos": []
    },
    {
      "role": "Volunteer",
      "title": "Relawan Komunitas Hijau",
      "org": "Komunitas Hijau Jakarta",
      "desc": "Ikut kegiatan bersih-bersih kota, kampanye lingkungan, dan workshop daur ulang untuk anak-anak. Suka banget karena bisa kontribusi langsung.",
      "period": "2024 — Sekarang",
      "photos": []
    },
    {
      "role": "Design Team",
      "title": "Tim Kreatif Sekolah",
      "org": "Media & Publikasi Sekolah",
      "desc": "Bikin feeds Instagram sekolah, poster acara, dan desain merchandise. Tempat pertama kali belajar bahwa desain itu powerful.",
      "period": "2023 — Sekarang",
      "photos": []
    },
    {
      "role": "Workshop",
      "title": "Panitia Workshop Desain",
      "org": "Youth Creative Festival 2024",
      "desc": "Panitia sekaligus MC di workshop desain grafis untuk pelajar. Ngajarin basic Canva dan Figma ke temen-temen yang baru mulai.",
      "period": "2024",
      "photos": []
    },
    {
      "role": "Komunitas",
      "title": "Anggota Pelajar.id",
      "org": "Komunitas Pelajar.id",
      "desc": "Komunitas online pelajar se-Indonesia. Tempat sharing project, ikutan challenge mingguan, dan dapat teman baru dari berbagai kota.",
      "period": "2024 — Sekarang",
      "photos": []
    }
  ],
  "education": [
    {
      "year": "2023 — Sekarang",
      "school": "SMA Negeri 1 Contoh Kota",
      "location": "Jakarta · Jurusan IPA",
      "desc": "Fokus di mata pelajaran sains dan aktif mengikuti ekstrakurikuler. Aktif di OSIS sebagai koordinator divisi acara dan menjadi mentor untuk adik kelas.",
      "tags": [
        "Matematika",
        "Fisika",
        "Bahasa Inggris",
        "Informatika"
      ]
    },
    {
      "year": "2020 — 2023",
      "school": "SMP Negeri 5 Contoh Kota",
      "location": "Jakarta",
      "desc": "Awal mula ketertarikan di bidang desain dan komputer. Mulai belajar Canva, bikin poster kelas, dan aktif di English Club.",
      "tags": [
        "Juara 2 Poster Kelas",
        "English Club",
        "Pramuka"
      ]
    }
  ],
  "achievements": [
    {
      "icon": "medal",
      "title": "Juara 2 Lomba Poster",
      "subtitle": "Tingkat kota — tahun 2023"
    },
    {
      "icon": "star",
      "title": "Finalis Speech Contest",
      "subtitle": "Sekolah — tahun 2024"
    },
    {
      "icon": "user",
      "title": "MC Upacara & Acara",
      "subtitle": "Lebih dari 5 event sekolah"
    },
    {
      "icon": "file",
      "title": "Sertifikasi Desain Grafis",
      "subtitle": "Pelajar.id Bootcamp 2024"
    },
    {
      "icon": "home",
      "title": "Ketua Kelas 3 Tahun Berturut",
      "subtitle": "SMP & SMA"
    },
    {
      "icon": "globe",
      "title": "Aktif di 4 Komunitas",
      "subtitle": "Sekolah & komunitas online"
    }
  ],
  "skills": [
    {
      "icon": "design",
      "title": "UI / UX Design",
      "subtitle": "Figma, Canva, design system"
    },
    {
      "icon": "code",
      "title": "Front-End Dev",
      "subtitle": "HTML, CSS, JavaScript basics"
    },
    {
      "icon": "speaking",
      "title": "Public Speaking",
      "subtitle": "Presentasi & MC acara"
    },
    {
      "icon": "leadership",
      "title": "Leadership",
      "subtitle": "Mengelola tim & event"
    },
    {
      "icon": "writing",
      "title": "Content Writing",
      "subtitle": "Copywriting & journaling"
    },
    {
      "icon": "visual",
      "title": "Visual Design",
      "subtitle": "Canva, ilustrasi, branding"
    },
    {
      "icon": "chat",
      "title": "Komunikasi",
      "subtitle": "Asik & mudah dipahami"
    },
    {
      "icon": "clock",
      "title": "Time Management",
      "subtitle": "Produktif & terorganisir"
    }
  ],
  "projects": [
    {
      "emoji": "📔",
      "tag": "UI/UX",
      "title": "Aplikasi Jurnal Harian",
      "desc": "Konsep aplikasi journaling buat pelajar dengan mood tracker dan reminder menulis setiap malam.",
      "tags": [
        "Figma",
        "UX Research",
        "Prototype"
      ],
      "link": ""
    },
    {
      "emoji": "🎨",
      "tag": "Branding",
      "title": "Branding Class Festival",
      "desc": "Identity design untuk festival kelas — logo, poster, feed IG, sampai merchandise. Tema: pastel cute aesthetic.",
      "tags": [
        "Canva",
        "Logo",
        "Poster"
      ],
      "link": ""
    },
    {
      "emoji": "🌱",
      "tag": "Campaign",
      "title": "Kampanye \"Hijaukan Sekolah\"",
      "desc": "Konsep kampanye lingkungan dengan poster, konten IG, dan video pendek ajak siswa peduli sampah plastik.",
      "tags": [
        "Design",
        "Content",
        "Video"
      ],
      "link": ""
    },
    {
      "emoji": "💌",
      "tag": "Web",
      "title": "Web Surat untuk Guru",
      "desc": "Mini web interaktif berisi surat digital ucapan dari siswa ke guru saat hari guru. Dibuat pakai HTML & CSS.",
      "tags": [
        "HTML",
        "CSS",
        "Animation"
      ],
      "link": ""
    }
  ],
  "socials": [
    {
      "key": "instagram",
      "label": "Instagram",
      "url": ""
    },
    {
      "key": "github",
      "label": "GitHub",
      "url": ""
    },
    {
      "key": "linkedin",
      "label": "LinkedIn",
      "url": ""
    },
    {
      "key": "twitter",
      "label": "Twitter",
      "url": ""
    },
    {
      "key": "dribbble",
      "label": "Dribbble",
      "url": ""
    }
  ]
};
