import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';
import { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } from '../config/supabase.js';
import { clone, sanitizeDataObject } from '../utils/sanitizer.js';

export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);

const BUCKET = 'portfolio-photos';

function fail(error, label) {
  if (error) throw new Error(`${label}: ${error.message || error}`);
}

async function getRows(table) {
  let query = supabase.from(table).select('*');
  if (!['profiles', 'about'].includes(table)) {
    query = query.order('sort_order', { ascending: true });
  }
  const { data, error } = await query;
  fail(error, `Load ${table}`);
  return data || [];
}

function rowToData(rows) {
  const profileRow = rows.profiles[0];
  const aboutRow = rows.about[0];

  const data = {
    config: {},
    profile: profileRow ? {
      id: profileRow.id,
      brandName: profileRow.brand_name,
      brandMark: profileRow.brand_mark,
      heroAccent: profileRow.hero_accent,
      heroLine2: profileRow.hero_line2,
      heroLine3: profileRow.hero_line3,
      heroLead: profileRow.hero_lead,
      email: profileRow.email,
      legalName: profileRow.legal_name,
      footerCredit: profileRow.footer_credit,
      photos: []
    } : null,
    about: aboutRow ? {
      id: aboutRow.id,
      hi: aboutRow.hi,
      heading: aboutRow.heading,
      p1: aboutRow.p1,
      p2: aboutRow.p2,
      factName: aboutRow.fact_name,
      factStatus: aboutRow.fact_status,
      factLocation: aboutRow.fact_location,
      factInterest: aboutRow.fact_interest,
      quoteAuthor: aboutRow.quote_author
    } : null,
    activities: rows.activities.map(r => ({
      id: r.id, role: r.role, title: r.title, org: r.org,
      desc: r.description, period: r.period, photos: []
    })),
    education: rows.education.map(r => ({
      id: r.id, year: r.year, school: r.school, location: r.location,
      desc: r.description, tags: Array.isArray(r.tags) ? r.tags : []
    })),
    achievements: rows.achievements.map(r => ({
      id: r.id, icon: r.icon, title: r.title, subtitle: r.subtitle
    })),
    skills: rows.skills.map(r => ({
      id: r.id, icon: r.icon, title: r.title, subtitle: r.subtitle
    })),
    projects: rows.projects.map(r => ({
      id: r.id, emoji: r.emoji, tag: r.tag, title: r.title,
      desc: r.description, tags: Array.isArray(r.tags) ? r.tags : [], link: r.link
    })),
    socials: rows.socials.map(r => ({
      id: r.id, key: r.social_key, label: r.label, url: r.url
    }))
  };

  for (const p of rows.photos) {
    const item = { id: p.id, src: p.public_url, caption: p.caption, storage_path: p.storage_path };
    if (p.photo_type === 'profile') data.profile?.photos.push(item);
    else {
      const act = data.activities.find(a => a.id === p.activity_id);
      if (act) act.photos.push(item);
    }
  }
  if (!data.profile) return null;
  return data;
}

export async function getSession() {
  const { data, error } = await supabase.auth.getSession();
  fail(error, 'Get session');
  return data.session;
}

export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data.session;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  fail(error, 'Logout');
}

export async function loadCloud(defaultData) {
  const tables = ['profiles','about','activities','education','achievements','skills','projects','socials','photos'];
  const entries = await Promise.all(tables.map(async t => [t, await getRows(t)]));
  const rows = Object.fromEntries(entries);
  if (!rows.profiles.length || !rows.about.length) return null;
  return sanitizeDataObject(rowToData(rows), defaultData);
}

async function upsertRows(table, rows) {
  if (!rows.length) return;
  const { error } = await supabase.from(table).upsert(rows);
  fail(error, `Save ${table}`);
}

async function deleteMissing(table, ids) {
  if (!ids.length) {
    const { error } = await supabase.from(table).delete().neq('id', '00000000-0000-0000-0000-000000000000');
    fail(error, `Clear ${table}`);
    return;
  }
  const { data: existing, error } = await supabase.from(table).select('id');
  fail(error, `Read ${table} ids`);
  const wanted = new Set(ids);
  const remove = (existing || []).map(x => x.id).filter(id => !wanted.has(id));
  if (remove.length) {
    const { error: delError } = await supabase.from(table).delete().in('id', remove);
    fail(delError, `Delete ${table}`);
  }
}

function ensureId(item) {
  if (!item.id) item.id = crypto.randomUUID();
  return item.id;
}

async function syncPhotos(data) {
  const { data: existing, error } = await supabase.from('photos').select('*');
  fail(error, 'Read photos');
  const existingById = new Map((existing || []).map(p => [p.id, p]));
  const desired = [];

  const groups = [
    ...data.profile.photos.map((p, index) => ({ p, type: 'profile', activityId: null, order: index })),
    ...data.activities.flatMap(a => a.photos.map((p, index) => ({ p, type: 'activity', activityId: a.id, order: index })))
  ];

  for (const { p, type, activityId, order } of groups) {
    ensureId(p);
    let path = p.storage_path || existingById.get(p.id)?.storage_path || '';
    let publicUrl = p.src;

    if (typeof p.src === 'string' && p.src.startsWith('data:image/')) {
      const blob = await (await fetch(p.src)).blob();
      const ext = blob.type === 'image/png' ? 'png' : 'jpg';
      const newPath = `${type}/${crypto.randomUUID()}.${ext}`;
      const { error: uploadError } = await supabase.storage.from(BUCKET).upload(newPath, blob, {
        contentType: blob.type,
        upsert: false
      });
      fail(uploadError, 'Upload photo');
      const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(newPath);
      publicUrl = pub.publicUrl;
      if (path && path !== newPath) {
        await supabase.storage.from(BUCKET).remove([path]);
      }
      path = newPath;
      p.src = publicUrl;
      p.storage_path = path;
    }

    desired.push({
      id: p.id,
      photo_type: type,
      activity_id: activityId,
      storage_path: path,
      public_url: publicUrl,
      caption: p.caption || '',
      sort_order: order
    });
  }

  const desiredIds = desired.map(p => p.id);
  if (desired.length) await upsertRows('photos', desired);
  else await deleteMissing('photos', []);

  const stale = (existing || []).filter(p => !desiredIds.includes(p.id));
  const stalePaths = stale.map(p => p.storage_path).filter(Boolean);
  if (stalePaths.length) await supabase.storage.from(BUCKET).remove(stalePaths);
  if (stale.length) {
    const { error } = await supabase.from('photos').delete().in('id', stale.map(p => p.id));
    fail(error, 'Delete stale photos');
  }
}

export async function saveCloud(data) {
  const profileId = ensureId(data.profile);
  const aboutId = ensureId(data.about);

  await upsertRows('profiles', [{
    id: profileId,
    brand_name: data.profile.brandName,
    brand_mark: data.profile.brandMark,
    hero_accent: data.profile.heroAccent,
    hero_line2: data.profile.heroLine2,
    hero_line3: data.profile.heroLine3,
    hero_lead: data.profile.heroLead,
    email: data.profile.email,
    legal_name: data.profile.legalName,
    footer_credit: data.profile.footerCredit
  }]);

  await upsertRows('about', [{
    id: aboutId,
    hi: data.about.hi,
    heading: data.about.heading,
    p1: data.about.p1,
    p2: data.about.p2,
    fact_name: data.about.factName,
    fact_status: data.about.factStatus,
    fact_location: data.about.factLocation,
    fact_interest: data.about.factInterest,
    quote_author: data.about.quoteAuthor
  }]);

  const activities = data.activities.map((a, i) => ({
    id: ensureId(a), role: a.role, title: a.title, org: a.org,
    description: a.desc, period: a.period, sort_order: i
  }));
  const education = data.education.map((x, i) => ({
    id: ensureId(x), year: x.year, school: x.school, location: x.location,
    description: x.desc, tags: x.tags || [], sort_order: i
  }));
  const achievements = data.achievements.map((x, i) => ({
    id: ensureId(x), icon: x.icon, title: x.title, subtitle: x.subtitle, sort_order: i
  }));
  const skills = data.skills.map((x, i) => ({
    id: ensureId(x), icon: x.icon, title: x.title, subtitle: x.subtitle, sort_order: i
  }));
  const projects = data.projects.map((x, i) => ({
    id: ensureId(x), emoji: x.emoji, tag: x.tag, title: x.title,
    description: x.desc, tags: x.tags || [], link: x.link, sort_order: i
  }));
  const socials = data.socials.map((x, i) => ({
    id: ensureId(x), social_key: x.key, label: x.label, url: x.url, sort_order: i
  }));

  await Promise.all([
    upsertRows('activities', activities),
    upsertRows('education', education),
    upsertRows('achievements', achievements),
    upsertRows('skills', skills),
    upsertRows('projects', projects),
    upsertRows('socials', socials)
  ]);

  await Promise.all([
    deleteMissing('activities', activities.map(x => x.id)),
    deleteMissing('education', education.map(x => x.id)),
    deleteMissing('achievements', achievements.map(x => x.id)),
    deleteMissing('skills', skills.map(x => x.id)),
    deleteMissing('projects', projects.map(x => x.id)),
    deleteMissing('socials', socials.map(x => x.id))
  ]);

  await syncPhotos(data);
}

export async function resetCloud() {
  const tables = ['photos','activities','education','achievements','skills','projects','socials','about','profiles'];
  for (const table of tables) {
    const { error } = await supabase.from(table).delete().neq('id', '00000000-0000-0000-0000-000000000000');
    fail(error, `Reset ${table}`);
  }
  const { data: objects, error: listError } = await supabase.storage.from(BUCKET).list('', { limit: 1000 });
  fail(listError, 'List storage');
  const paths = [];
  for (const prefix of ['profile','activity']) {
    const { data: items } = await supabase.storage.from(BUCKET).list(prefix, { limit: 1000 });
    for (const item of (items || [])) paths.push(`${prefix}/${item.name}`);
  }
  if (paths.length) await supabase.storage.from(BUCKET).remove(paths);
}

export async function migrateLegacyData(defaultData, sanitize, localData) {
  if (!localData) return false;
  const existing = await loadCloud(defaultData);
  if (existing) return false;
  await saveCloud(localData);
  return true;
}
