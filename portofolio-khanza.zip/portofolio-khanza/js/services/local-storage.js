const STORAGE_KEY = 'khanza_portfolio_v1';

export function loadLocal(defaultData, sanitizeDataObject) {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return sanitizeDataObject(JSON.parse(raw), defaultData);
  } catch {
    return null;
  }
}

export function saveLocal(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // Cloud is the source of truth; local cache is only a convenience.
  }
}

export function clearLocal() {
  localStorage.removeItem(STORAGE_KEY);
}
