export function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

export function sanitizeUrl(url) {
  if (!url || typeof url !== 'string') return '';
  let trimmed = url.trim();
  if (!trimmed) return '';
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(trimmed) && !trimmed.startsWith('//')) {
    trimmed = 'https://' + trimmed;
  }
  try {
    const u = new URL(trimmed);
    return (u.protocol === 'http:' || u.protocol === 'https:') ? u.href : '';
  } catch {
    return '';
  }
}

export function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({
    '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
  }[c]));
}

export function sanitizePhotoArray(photos) {
  if (!Array.isArray(photos)) return [];
  return photos
    .filter(p => p && typeof p.src === 'string' && p.src)
    .map(p => ({
      id: typeof p.id === 'string' ? p.id : '',
      src: p.src,
      caption: typeof p.caption === 'string' ? p.caption : '',
      storage_path: typeof p.storage_path === 'string' ? p.storage_path : ''
    }));
}

export function sanitizeDataObject(parsed, defaults) {
  const p = (parsed && typeof parsed === 'object') ? parsed : {};
  const base = clone(defaults);

  base.profile = {
    ...base.profile,
    ...(p.profile && typeof p.profile === 'object' ? p.profile : {}),
    photos: sanitizePhotoArray(p.profile?.photos)
  };

  base.about = { ...base.about, ...(p.about && typeof p.about === 'object' ? p.about : {}) };

  const arrayCopy = (name) => Array.isArray(p[name]) ? p[name] : base[name];
  base.activities = arrayCopy('activities').map(x => ({
    id: x?.id || '',
    role: typeof x?.role === 'string' ? x.role : '',
    title: typeof x?.title === 'string' ? x.title : '',
    org: typeof x?.org === 'string' ? x.org : '',
    desc: typeof x?.desc === 'string' ? x.desc : '',
    period: typeof x?.period === 'string' ? x.period : '',
    photos: sanitizePhotoArray(x?.photos)
  }));
  base.education = arrayCopy('education').map(x => ({
    id: x?.id || '',
    year: typeof x?.year === 'string' ? x.year : '',
    school: typeof x?.school === 'string' ? x.school : '',
    location: typeof x?.location === 'string' ? x.location : '',
    desc: typeof x?.desc === 'string' ? x.desc : '',
    tags: Array.isArray(x?.tags) ? x.tags.filter(t => typeof t === 'string') : []
  }));
  base.achievements = arrayCopy('achievements').map(x => ({
    id: x?.id || '',
    icon: typeof x?.icon === 'string' ? x.icon : 'medal',
    title: typeof x?.title === 'string' ? x.title : '',
    subtitle: typeof x?.subtitle === 'string' ? x.subtitle : ''
  }));
  base.skills = arrayCopy('skills').map(x => ({
    id: x?.id || '',
    icon: typeof x?.icon === 'string' ? x.icon : 'design',
    title: typeof x?.title === 'string' ? x.title : '',
    subtitle: typeof x?.subtitle === 'string' ? x.subtitle : ''
  }));
  base.projects = arrayCopy('projects').map(x => ({
    id: x?.id || '',
    emoji: typeof x?.emoji === 'string' ? x.emoji : '📁',
    tag: typeof x?.tag === 'string' ? x.tag : '',
    title: typeof x?.title === 'string' ? x.title : '',
    desc: typeof x?.desc === 'string' ? x.desc : '',
    tags: Array.isArray(x?.tags) ? x.tags.filter(t => typeof t === 'string') : [],
    link: typeof x?.link === 'string' ? x.link : ''
  }));
  base.socials = base.socials.map(def => {
    const found = Array.isArray(p.socials) ? p.socials.find(x => x?.key === def.key || x?.social_key === def.key) : null;
    return { id: found?.id || '', key: def.key, label: def.label, url: typeof found?.url === 'string' ? found.url : '' };
  });
  // Client-side password is intentionally not supported after the Supabase migration.
  base.config = {};
  return base;
}
