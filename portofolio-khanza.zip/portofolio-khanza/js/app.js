import { defaultData } from './data/default-data.js';
import { clone, sanitizeDataObject, sanitizePhotoArray, sanitizeUrl, escapeHtml } from './utils/sanitizer.js';
import { loadLocal, saveLocal, clearLocal } from './services/local-storage.js';
import {
  supabase, getSession, signIn, signOut, loadCloud, saveCloud, resetCloud, migrateLegacyData
} from './services/supabase.js';


// =====================
// DATA STORE
// =====================
const STORAGE_KEY = 'khanza_portfolio_v1';

// Default data is imported from js/data/default-data.js.

// State aplikasi (single source of truth) — dimuat sekali saat halaman dibuka
let data = loadData();
let cloudReady = false;
let adminSession = null;

function loadData() {
  return loadLocal(defaultData, sanitizeDataObject) || clone(defaultData);
}

async function saveData() {
  saveLocal(data);
  if (!cloudReady || !adminSession) {
    showToast('Login admin diperlukan untuk menyimpan ke cloud.', 'error');
    return false;
  }
  try {
    await saveCloud(data);
    return true;
  } catch (error) {
    console.error(error);
    showToast(`Gagal menyimpan ke Supabase: ${error.message}`, 'error');
    return false;
  }
}


/**
 * Membersihkan/menyeragamkan array foto galeri berbentuk {src, caption}.
 * Item yang tidak valid (bukan object / src bukan string / src kosong) dibuang,
 * supaya data yang korup di localStorage tidak bikin galeri error saat dirender.
 */


/**
 * Memvalidasi URL sebelum dipakai sebagai href link yang bisa diklik pengunjung.
 * Hanya mengizinkan skema http/https — menolak skema berbahaya seperti javascript:
 * atau data: yang bisa dipakai untuk menjalankan script (XSS) lewat sebuah link.
 * Kalau user lupa menulis skema (mis. cuma "instagram.com/user"), otomatis
 * dianggap https:// supaya tetap nyaman dipakai.
 * @param {string} url - URL mentah dari data (link proyek / URL sosial media)
 * @returns {string} URL yang aman dipakai, atau string kosong kalau tidak valid/berbahaya
 */


/**
 * Mengubah objek data mentah (dari localStorage ATAU dari file JSON yang di-import user)
 * jadi objek data yang aman & lengkap — setiap field divalidasi tipe & di-fallback kalau
 * tidak valid, supaya data korup/rusak/jahat tidak bisa merusak halaman atau menyelundupkan
 * apapun. Ini SATU-SATUNYA tempat aturan validasi ditulis, dipakai oleh loadData() (baca dari
 * localStorage) dan importData() (baca dari file JSON) supaya keduanya konsisten.
 * @param {object} parsed - objek data mentah, HASIL JSON.parse (belum tentu bentuknya benar)
 * @returns {object} data yang sudah aman dipakai oleh seluruh aplikasi
 */




/** Menyimpan state `data` saat ini ke localStorage. Menangani kondisi storage penuh. */


// =====================
// RENDER CONTENT FROM DATA
// =====================
/**
 * Fungsi utama render: menyinkronkan semua elemen di halaman dengan isi `data`.
 * Dipanggil saat halaman pertama kali load, dan setelah saveSettings()/resetAll().
 */
function applyData() {
  // Brand
  document.getElementById('brandName').textContent = data.profile.brandName;
  document.getElementById('brandMark').textContent = data.profile.brandMark;
  document.title = data.profile.brandName + ' — Portfolio';
  document.getElementById('pageTitle').textContent = document.title;
  document.getElementById('footerName').textContent = data.profile.brandName;
  document.getElementById('footerBrandMark').textContent = data.profile.brandMark;
  document.getElementById('footerTagline').textContent = data.profile.heroLead;

  // Hero
  document.getElementById('heroAccent').textContent = data.profile.heroAccent;
  document.getElementById('heroLine2').textContent = data.profile.heroLine2;
  document.getElementById('heroLine3').textContent = data.profile.heroLine3;
  document.getElementById('heroLead').textContent = data.profile.heroLead;

  // About
  document.getElementById('aboutHi').textContent = data.about.hi;
  document.getElementById('aboutHeading').textContent = data.about.heading;
  document.getElementById('aboutP1').textContent = data.about.p1;
  document.getElementById('aboutP2').textContent = data.about.p2;
  document.getElementById('factName').textContent = data.about.factName;
  document.getElementById('factStatus').textContent = data.about.factStatus;
  document.getElementById('factLocation').textContent = data.about.factLocation;
  document.getElementById('factInterest').textContent = data.about.factInterest;
  document.getElementById('quoteAuthor').textContent = data.about.quoteAuthor;

  // Email
  const email = data.profile.email;
  document.getElementById('contactEmail').href = 'mailto:' + email;
  document.getElementById('contactEmailText').textContent = email;
  document.getElementById('footerEmail').href = 'mailto:' + email;
  document.getElementById('footerEmail').textContent = email;
  document.getElementById('footerLocation').textContent = data.about.factLocation;

  // Tahun hak cipta di footer selalu ikut tahun berjalan, tidak perlu diedit manual
  document.getElementById('footerYear').textContent = new Date().getFullYear();
  document.getElementById('footerLegalName').textContent = data.profile.legalName;
  document.getElementById('footerCredit').textContent = data.profile.footerCredit;

  // Profile photo
  renderProfilePhoto();

  // Activities
  renderActivities();

  // Education
  renderEducation();

  // Achievements (pencapaian)
  renderAchievements();

  // Skills
  renderSkills();

  // Projects
  renderProjects();

  // Sosial media (Kontak + Footer)
  renderSocials();
}

/** Merender daftar riwayat pendidikan (timeline) dari data.education ke #educationTimeline. */
function renderEducation() {
  const tl = document.getElementById('educationTimeline');
  if (!tl) return;
  tl.innerHTML = data.education.map((e, i) => `
    <div class="tl-item reveal">
      <div class="year">${escapeHtml(e.year)}</div>
      <h4>${escapeHtml(e.school)}</h4>
      <div class="where">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
        ${escapeHtml(e.location)}
      </div>
      <div class="edu-card">
        <p>${escapeHtml(e.desc)}</p>
        ${e.tags && e.tags.length ? `<div class="edu-tags">${e.tags.map(t => `<span>${escapeHtml(t)}</span>`).join('')}</div>` : ''}
      </div>
    </div>
  `).join('');
  // Re-attach reveal observer
  tl.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
}

/** Merender ulang foto sampul profil di homepage (photos[0]) berdasarkan data.profile.photos. */
function renderProfilePhoto() {
  const img = document.getElementById('profilePhotoImg');
  const ph = document.getElementById('profilePhotoPlaceholder');
  const initialEl = document.getElementById('profileInitial');
  // Inisial ditampilkan dari huruf pertama brand mark saat belum ada foto
  if (initialEl) initialEl.textContent = (data.profile.brandMark || 'K').toUpperCase();
  const cover = data.profile.photos[0]; // foto pertama di galeri = foto sampul
  if (cover) {
    img.src = cover.src;
    img.style.display = 'block';
    ph.style.display = 'none';
  } else {
    img.style.display = 'none';
    img.removeAttribute('src');
    ph.style.display = 'flex';
  }
}

/** Merender kartu kegiatan/organisasi dari data.activities ke #activitiesGrid, lengkap dengan foto (jika ada). */
function renderActivities() {
  const grid = document.getElementById('activitiesGrid');
  const icons = [
    '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>',
    '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>',
    '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>',
    '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
    '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>',
    '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>'
  ];

  grid.innerHTML = data.activities.map((a, i) => {
    const cover = a.photos[0]; // foto pertama = foto preview di kartu
    return `
    <div class="act-card reveal">
      <div class="act-photo" ${a.photos.length ? `onclick="openActivityGallery(${i})"` : ''}>
        ${cover
          ? `<img src="${escapeHtml(cover.src)}" alt="${escapeHtml(a.title)}"/>`
          : `<div class="photo-placeholder-static">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                <circle cx="8.5" cy="8.5" r="1.5"/>
                <polyline points="21 15 16 10 5 21"/>
              </svg>
            </div>`
        }
      </div>
      ${a.photos.length ? `
      <button type="button" class="view-more-btn" onclick="openActivityGallery(${i})">
        👆 Sentuh untuk melihat foto ${escapeHtml(a.title)} lainnya${a.photos.length > 1 ? ` (${a.photos.length})` : ''}
      </button>` : ''}
      <div class="act-body">
        <div class="ico">${icons[i % icons.length]}</div>
        <div class="role">${escapeHtml(a.role)}</div>
        <h4>${escapeHtml(a.title)}</h4>
        <div class="org">${escapeHtml(a.org)}</div>
        <p>${escapeHtml(a.desc)}</p>
        <div class="period">${escapeHtml(a.period)}</div>
      </div>
    </div>
  `;
  }).join('');

  // Re-attach reveal observer to new cards
  document.querySelectorAll('.act-card.reveal').forEach((el) => observer.observe(el));
}

// =====================
// PHOTO GALLERY (lightbox) — dipakai untuk foto profil & foto tiap kegiatan
// =====================
let galleryPhotos = [];  // array {src, caption} yang sedang ditampilkan di lightbox
let galleryIndex = 0;    // index foto yang sedang dilihat

/**
 * Membuka lightbox galeri untuk melihat semua foto + caption. Tidak melakukan apa-apa
 * kalau array foto kosong (tidak ada yang bisa dilihat).
 * @param {Array} photos - array {src, caption}
 * @param {string} title - judul galeri (nama kegiatan / "Foto Profil")
 */
function openGallery(photos, title) {
  if (!photos || photos.length === 0) return;
  galleryPhotos = photos;
  galleryIndex = 0;
  document.getElementById('galleryTitle').textContent = title || '';
  renderGalleryFrame();
  document.getElementById('galleryModal').classList.add('open');
}

/** Membuka galeri foto profil (dipanggil dari tap foto profil di homepage). */
function openProfileGallery() {
  openGallery(data.profile.photos, 'Foto Profil');
}

/** Membuka galeri foto satu kegiatan tertentu. @param {number} idx - index di data.activities */
function openActivityGallery(idx) {
  const act = data.activities[idx];
  if (!act) return;
  openGallery(act.photos, act.title);
}

/** Menutup lightbox galeri. */
function closeGallery() {
  document.getElementById('galleryModal').classList.remove('open');
}

/** Pindah ke foto sebelumnya di galeri (berputar ke akhir kalau di foto pertama). */
function galleryPrev() {
  if (galleryPhotos.length === 0) return;
  galleryIndex = (galleryIndex - 1 + galleryPhotos.length) % galleryPhotos.length;
  renderGalleryFrame();
}

/** Pindah ke foto berikutnya di galeri (berputar ke awal kalau di foto terakhir). */
function galleryNext() {
  if (galleryPhotos.length === 0) return;
  galleryIndex = (galleryIndex + 1) % galleryPhotos.length;
  renderGalleryFrame();
}

/** Merender ulang tampilan lightbox (foto, caption, counter) sesuai galleryIndex saat ini. */
function renderGalleryFrame() {
  const p = galleryPhotos[galleryIndex];
  if (!p) return;
  document.getElementById('galleryImg').src = p.src;
  const captionEl = document.getElementById('galleryCaption');
  captionEl.textContent = p.caption || '';
  captionEl.style.display = p.caption ? 'block' : 'none';
  document.getElementById('galleryCounter').textContent =
    galleryPhotos.length > 1 ? `${galleryIndex + 1} / ${galleryPhotos.length}` : '';
  // Tombol panah kiri/kanan cuma relevan kalau fotonya lebih dari satu
  document.querySelectorAll('.gallery-nav').forEach(btn => {
    btn.style.display = galleryPhotos.length > 1 ? 'grid' : 'none';
  });
}

// Peta ikon yang tersedia untuk item Pencapaian — dipilih user lewat <select> di Settings.
// Kalau nanti mau menambah pilihan ikon baru, cukup tambah entry di sini + di achievementIconLabels.
const achievementIcons = {
  medal: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>',
  star: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
  user: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
  file: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
  home: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
  globe: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>',
  trophy: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0V4z"/><path d="M17 5h3a2 2 0 01-2 4h-1M7 5H4a2 2 0 002 4h1"/></svg>',
  target: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>'
};
const achievementIconLabels = {
  medal: '🏅 Medali', star: '⭐ Bintang', user: '🧑 Individu', file: '📄 Sertifikat',
  home: '🏠 Rumah/Kelas', globe: '🌐 Komunitas', trophy: '🏆 Piala', target: '🎯 Target'
};

/** Merender kartu pencapaian dari data.achievements (jumlah bebas) ke #achievementsGrid. */
function renderAchievements() {
  const grid = document.getElementById('achievementsGrid');
  if (!grid) return;
  grid.innerHTML = data.achievements.map(a => `
    <div class="ach reveal">
      <div class="ico">${achievementIcons[a.icon] || achievementIcons.medal}</div>
      <div>
        <h5>${escapeHtml(a.title)}</h5>
        <p>${escapeHtml(a.subtitle)}</p>
      </div>
    </div>
  `).join('');
  // Re-attach reveal observer ke kartu baru (pola sama seperti renderActivities/renderEducation)
  grid.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
}

// Peta ikon yang tersedia untuk item Skill — dipilih user lewat <select> di Settings.
const skillIcons = {
  design: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="M2 2l7.586 7.586"/><circle cx="11" cy="11" r="2"/></svg>',
  code: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
  speaking: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>',
  leadership: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>',
  writing: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
  visual: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
  chat: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>',
  clock: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
  target: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>'
};
const skillIconLabels = {
  design: '🎨 Desain', code: '💻 Kode', speaking: '🎤 Bicara', leadership: '🧑\u200d🤝\u200d🧑 Leadership',
  writing: '✍️ Menulis', visual: '🖼️ Visual', chat: '💬 Komunikasi', clock: '⏰ Waktu', target: '🎯 Target'
};

/** Merender kartu skill dari data.skills (jumlah bebas) ke #skillsGrid. */
function renderSkills() {
  const grid = document.getElementById('skillsGrid');
  if (!grid) return;
  grid.innerHTML = data.skills.map(s => `
    <div class="skill-card reveal">
      <div class="skill-icon">${skillIcons[s.icon] || skillIcons.design}</div>
      <h4>${escapeHtml(s.title)}</h4>
      <p>${escapeHtml(s.subtitle)}</p>
    </div>
  `).join('');
  // Re-attach reveal observer ke kartu baru (pola sama seperti renderActivities/renderAchievements)
  grid.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
}

/**
 * Merender kartu proyek dari data.projects (jumlah bebas) ke #projectsGrid.
 * Kartu proyek yang punya 'link' terisi jadi bisa disentuh dan membuka link itu di tab baru;
 * yang tidak punya link tetap tampil tapi tidak bisa diklik (bukan link kosong "#").
 */
function renderProjects() {
  const grid = document.getElementById('projectsGrid');
  if (!grid) return;
  grid.innerHTML = data.projects.map(p => {
    const safeLink = sanitizeUrl(p.link);
    const hasLink = !!safeLink;
    const tag = hasLink ? 'a' : 'div';
    const linkAttrs = hasLink ? `href="${escapeHtml(safeLink)}" target="_blank" rel="noopener noreferrer"` : '';
    return `
    <${tag} class="proj-card reveal" ${linkAttrs}>
      <div class="proj-cover">
        <div class="grad"></div>
        <div class="emoji">${escapeHtml(p.emoji)}</div>
        ${p.tag ? `<div class="tag">${escapeHtml(p.tag)}</div>` : ''}
      </div>
      <div class="proj-body">
        <h4>${escapeHtml(p.title)}</h4>
        <p>${escapeHtml(p.desc)}</p>
        <div class="proj-tags">
          ${(p.tags || []).map(t => `<span>${escapeHtml(t)}</span>`).join('')}
        </div>
      </div>
    </${tag}>
  `;
  }).join('');
  // Re-attach reveal observer ke kartu baru (pola sama seperti section lain)
  grid.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
}

// Ikon tetap per-platform (bukan pilihan bebas seperti achievements/skills, karena
// tiap platform sosial punya bentuk logo yang sudah baku)
const socialIcons = {
  instagram: '<svg width="__SIZE__" height="__SIZE__" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>',
  github: '<svg width="__SIZE__" height="__SIZE__" viewBox="0 0 24 24" fill="currentColor"><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.1.79-.25.79-.56v-2c-3.2.7-3.87-1.36-3.87-1.36-.52-1.32-1.27-1.67-1.27-1.67-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.18 1.76 1.18 1.02 1.76 2.69 1.25 3.34.96.1-.74.4-1.25.72-1.54-2.55-.29-5.24-1.27-5.24-5.66 0-1.25.45-2.27 1.18-3.07-.12-.29-.51-1.46.11-3.05 0 0 .96-.31 3.15 1.17a10.93 10.93 0 015.74 0c2.19-1.48 3.15-1.17 3.15-1.17.62 1.59.23 2.76.11 3.05.74.8 1.18 1.82 1.18 3.07 0 4.4-2.69 5.37-5.25 5.65.41.35.78 1.05.78 2.12v3.14c0 .31.21.67.8.55A11.51 11.51 0 0023.5 12C23.5 5.65 18.35.5 12 .5z"/></svg>',
  linkedin: '<svg width="__SIZE__" height="__SIZE__" viewBox="0 0 24 24" fill="currentColor"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.13 1.45-2.13 2.94v5.67H9.36V9h3.41v1.56h.05c.48-.9 1.65-1.85 3.4-1.85 3.63 0 4.3 2.39 4.3 5.5v6.24zM5.34 7.43a2.06 2.06 0 11.01-4.12 2.06 2.06 0 010 4.12zM7.12 20.45H3.55V9h3.57v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.55C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.72V1.72C24 .77 23.2 0 22.22 0z"/></svg>',
  twitter: '<svg width="__SIZE__" height="__SIZE__" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
  dribbble: '<svg width="__SIZE__" height="__SIZE__" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M8.56 2.75c4.37 6.03 6.02 9.42 8.03 17.72M21.13 15.73c-5.12-3.43-10.46-3.43-15.59 0M15.66 21.37C12.78 15.04 9.36 8.61 4.76 4.18"/></svg>'
};

/**
 * Merender ikon sosial media ke sebuah container, hanya menampilkan platform yang
 * URL-nya sudah diisi (URL kosong = ikon disembunyikan, bukan link mati "#").
 * @param {string} containerId - id elemen tujuan (dipakai untuk #contactSocials & #footerSocials)
 * @param {number} size - ukuran ikon dalam px
 */
function renderSocialsInto(containerId, size) {
  const el = document.getElementById(containerId);
  if (!el) return;
  // Hanya tampilkan platform yang URL-nya lolos validasi (aman & tidak kosong)
  const active = data.socials
    .map(s => ({ ...s, safeUrl: sanitizeUrl(s.url) }))
    .filter(s => s.safeUrl);
  el.innerHTML = active.map(s => `
    <a href="${escapeHtml(s.safeUrl)}" target="_blank" rel="noopener noreferrer" aria-label="${escapeHtml(s.label)}">
      ${(socialIcons[s.key] || '').split('__SIZE__').join(size)}
    </a>
  `).join('');
}

/** Merender ikon sosial media ke section Kontak dan ke footer sekaligus, dari data.socials yang sama. */
function renderSocials() {
  renderSocialsInto('contactSocials', 22);
  renderSocialsInto('footerSocials', 18);
}

/**
 * Meng-escape karakter HTML berbahaya (&, <, >, ", ') sebelum teks disisipkan
 * lewat innerHTML/template string, supaya input user tidak bisa merusak layout
 * atau menyuntikkan HTML/script (self-XSS).
 */


// =====================
// IMAGE HANDLING (compress + store)
// =====================
/**
 * Mengompres & meresize gambar sebelum disimpan sebagai base64 di localStorage
 * (localStorage sangat terbatas, jadi foto ukuran asli tidak akan muat).
 * @param {File} file - file gambar dari <input type="file">
 * @param {number} maxSize - sisi terpanjang maksimum hasil (px)
 * @param {number} quality - kualitas JPEG (0-1)
 * @returns {Promise<string>} data URL gambar hasil kompresi
 */
// =====================
// PHOTO CROPPER — dipakai di SEMUA titik upload foto (profil & tiap kegiatan).
// User crop dulu (geser + zoom) sebelum foto disimpan; hasil crop di-render ke canvas
// ukuran tetap, yang sekaligus jadi tahap resize/compress-nya.
// =====================
let cropState = null; // state cropper yang sedang aktif, null kalau modal sedang tertutup

/**
 * Membuka cropper untuk sebuah file gambar yang baru dipilih user.
 * @param {File} file - file gambar dari <input type="file">
 * @param {number} aspect - rasio lebar/tinggi target crop (4/5 untuk profil, 16/10 untuk kegiatan)
 * @param {function(string)} onConfirm - dipanggil dengan data URL hasil crop kalau user menekan "Pakai Foto Ini"
 */
function openCropper(file, aspect, onConfirm) {
  if (!file || !file.type || !file.type.startsWith('image/')) {
    showToast('File yang dipilih bukan gambar', 'error');
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const viewport = document.getElementById('cropViewport');
      const vpW = viewport.clientWidth || 300;
      const vpH = vpW / aspect;
      viewport.style.height = vpH + 'px';

      // Skala minimum supaya gambar selalu menutupi viewport penuh (tidak ada celah kosong)
      const minScale = Math.max(vpW / img.naturalWidth, vpH / img.naturalHeight);
      cropState = {
        img, aspect, vpW, vpH,
        naturalW: img.naturalWidth, naturalH: img.naturalHeight,
        minScale, scale: minScale,
        offsetX: 0, offsetY: 0,
        dragging: false, dragStartX: 0, dragStartY: 0, offsetStartX: 0, offsetStartY: 0,
        onConfirm
      };

      document.getElementById('cropImg').src = reader.result;
      document.getElementById('cropZoomSlider').value = 0;
      renderCropFrame();
      document.getElementById('cropModal').classList.add('open');
    };
    img.onerror = () => showToast('Gagal membaca gambar — file mungkin rusak', 'error');
    img.src = reader.result;
  };
  reader.onerror = () => showToast('Gagal membaca file', 'error');
  reader.readAsDataURL(file);
}

/** Membatasi offset geser supaya gambar selalu menutupi viewport penuh (tidak ada celah kosong terlihat). */
function clampCropOffset() {
  const s = cropState;
  const dispW = s.naturalW * s.scale;
  const dispH = s.naturalH * s.scale;
  const maxX = Math.max(0, (dispW - s.vpW) / 2);
  const maxY = Math.max(0, (dispH - s.vpH) / 2);
  s.offsetX = Math.min(maxX, Math.max(-maxX, s.offsetX));
  s.offsetY = Math.min(maxY, Math.max(-maxY, s.offsetY));
}

/** Menerapkan posisi & skala gambar saat ini (cropState) ke elemen <img> di viewport cropper. */
function renderCropFrame() {
  if (!cropState) return;
  clampCropOffset();
  const cropImg = document.getElementById('cropImg');
  cropImg.style.width = cropState.naturalW + 'px';
  cropImg.style.height = cropState.naturalH + 'px';
  cropImg.style.transform =
    `translate(-50%, -50%) translate(${cropState.offsetX}px, ${cropState.offsetY}px) scale(${cropState.scale})`;
}

/** Dipanggil saat slider zoom digeser. value 0 = minScale (paling zoom out tapi tetap menutupi viewport), 100 = minScale x3. */
function onCropZoomInput(value) {
  if (!cropState) return;
  cropState.scale = cropState.minScale * (1 + 2 * (value / 100));
  renderCropFrame();
}

/** Memulai drag geser gambar (dipanggil dari pointerdown). */
function cropDragStart(clientX, clientY) {
  if (!cropState) return;
  cropState.dragging = true;
  cropState.dragStartX = clientX;
  cropState.dragStartY = clientY;
  cropState.offsetStartX = cropState.offsetX;
  cropState.offsetStartY = cropState.offsetY;
  document.getElementById('cropViewport').classList.add('dragging');
}
/** Melanjutkan drag geser gambar (dipanggil dari pointermove). */
function cropDragMove(clientX, clientY) {
  if (!cropState || !cropState.dragging) return;
  cropState.offsetX = cropState.offsetStartX + (clientX - cropState.dragStartX);
  cropState.offsetY = cropState.offsetStartY + (clientY - cropState.dragStartY);
  renderCropFrame();
}
/** Mengakhiri drag geser gambar (dipanggil dari pointerup/pointercancel). */
function cropDragEnd() {
  if (!cropState) return;
  cropState.dragging = false;
  const viewport = document.getElementById('cropViewport');
  if (viewport) viewport.classList.remove('dragging');
}

/** Menutup cropper tanpa menyimpan apapun (foto yang sudah dipilih dibatalkan). */
function cancelCrop() {
  document.getElementById('cropModal').classList.remove('open');
  cropState = null;
}

/**
 * Mengambil area yang sedang terlihat di viewport, menggambarnya ke canvas ukuran tetap,
 * lalu memanggil callback (onConfirm) dengan data URL hasilnya (JPEG terkompresi).
 * Ini sekaligus jadi tahap resize & compress fotonya.
 */
function confirmCrop() {
  if (!cropState) return;
  const s = cropState;

  // Titik tengah viewport, dikonversi ke koordinat piksel GAMBAR ASLI (bukan yang sudah di-scale)
  const centerX = s.naturalW / 2 - s.offsetX / s.scale;
  const centerY = s.naturalH / 2 - s.offsetY / s.scale;
  const cropW = s.vpW / s.scale;
  const cropH = s.vpH / s.scale;
  const srcX = centerX - cropW / 2;
  const srcY = centerY - cropH / 2;

  // Ukuran output tetap (dibatasi supaya ukuran file tidak kebesaran buat localStorage)
  const outputW = 800;
  const outputH = Math.round(800 / s.aspect);

  const canvas = document.createElement('canvas');
  canvas.width = outputW;
  canvas.height = outputH;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(s.img, srcX, srcY, cropW, cropH, 0, 0, outputW, outputH);
  const dataUrl = canvas.toDataURL('image/jpeg', 0.85);

  const callback = s.onConfirm;
  document.getElementById('cropModal').classList.remove('open');
  cropState = null;
  if (callback) callback(dataUrl);
}

// Drag geser gambar di cropper — pakai Pointer Events supaya mouse & sentuhan HP sama-sama jalan
(function setupCropDragListeners() {
  const viewport = document.getElementById('cropViewport');
  if (!viewport) return;
  viewport.addEventListener('pointerdown', (e) => {
    viewport.setPointerCapture(e.pointerId);
    cropDragStart(e.clientX, e.clientY);
  });
  viewport.addEventListener('pointermove', (e) => cropDragMove(e.clientX, e.clientY));
  viewport.addEventListener('pointerup', cropDragEnd);
  viewport.addEventListener('pointercancel', cropDragEnd);
})();

// Menyimpan sementara index foto profil yang sedang mau "diganti" (diisi tepat sebelum
// file picker dibuka, dipakai lagi saat file-nya sudah dipilih)
let profilePhotoReplaceIdx = null;

/** Membuka file picker untuk mengganti isi satu foto profil tertentu. @param {number} idx */
function triggerReplaceProfilePhoto(idx) {
  profilePhotoReplaceIdx = idx;
  document.getElementById('profilePhotoReplaceInput').click();
}

/** Menangani hasil pilih file dari triggerReplaceProfilePhoto() — buka cropper, lalu ganti src foto pada index yang tersimpan. */
async function handleProfilePhotoReplace(event) {
  const file = event.target.files[0];
  const idx = profilePhotoReplaceIdx;
  profilePhotoReplaceIdx = null;
  event.target.value = '';
  if (!file || idx === null || !data.profile.photos[idx]) return;
  openCropper(file, 4 / 5, async (dataUrl) => {
    if (!data.profile.photos[idx]) return;
    data.profile.photos[idx].src = dataUrl;
    await saveData();
    renderProfilePhotoEditor();
    renderProfilePhoto();
    showToast('Foto diganti ✓', 'success');
  });
}

/** Menambah foto baru ke galeri foto profil (dipicu tombol "+ Tambah Foto" di Settings). Buka cropper dulu. */
async function handleProfilePhotoAdd(event) {
  const file = event.target.files[0];
  event.target.value = '';
  if (!file) return;
  openCropper(file, 4 / 5, async (dataUrl) => {
    data.profile.photos.push({ src: dataUrl, caption: '' });
    await saveData();
    renderProfilePhotoEditor();
    renderProfilePhoto();
    showToast('Foto ditambahkan ✓', 'success');
  });
}

/** Menghapus satu foto dari galeri foto profil (dengan konfirmasi). @param {number} idx */
async function removeProfilePhoto(idx) {
  if (!confirm('Hapus foto ini?')) return;
  data.profile.photos.splice(idx, 1);
  await saveData();
  renderProfilePhotoEditor();
  renderProfilePhoto();
  showToast('Foto dihapus', 'success');
}

/** Membangun daftar editor foto profil (thumbnail + caption + tombol ganti/hapus per foto). */
function renderProfilePhotoEditor() {
  const editor = document.getElementById('profilePhotoEditor');
  if (!editor) return;
  if (data.profile.photos.length === 0) {
    editor.innerHTML = '<p class="hint">Belum ada foto. Klik "+ Tambah Foto" di bawah untuk menambahkan.</p>';
    return;
  }
  editor.innerHTML = '<div class="photo-list">' + data.profile.photos.map((p, i) => `
    <div class="photo-list-item">
      <img class="thumb" src="${escapeHtml(p.src)}" alt="Foto profil ${i+1}"/>
      <div class="photo-list-body">
        <input type="text" placeholder="Caption foto (opsional)" data-profile-photo-caption data-idx="${i}" value="${escapeHtml(p.caption)}"/>
        <div class="photo-list-actions">
          ${i === 0 ? '<span style="font-size:11px; color:var(--primary); font-weight:600; align-self:center; padding:0 4px;">📌 Foto sampul</span>' : ''}
          <button type="button" onclick="triggerReplaceProfilePhoto(${i})">🔄 Ganti Foto Ini</button>
          <button type="button" class="danger" onclick="removeProfilePhoto(${i})">🗑 Hapus Foto Ini</button>
        </div>
      </div>
    </div>
  `).join('') + '</div>';
}

/**
 * Menambah foto baru ke galeri foto satu kegiatan tertentu. Buka cropper dulu (aspect 16:10,
 * sesuai bentuk tampilan foto kegiatan di kartu).
 * @param {Event} event - event 'change' dari <input type="file">
 * @param {number} actIdx - index kegiatan di data.activities
 */
async function handleActivityPhotoAdd(event, actIdx) {
  const file = event.target.files[0];
  event.target.value = '';
  if (!file) return;
  openCropper(file, 16 / 10, async (dataUrl) => {
    if (!data.activities[actIdx]) return;
    data.activities[actIdx].photos.push({ src: dataUrl, caption: '' });
    await saveData();
    renderActivities();
    renderActivitiesEditor();
    showToast('Foto ditambahkan ✓', 'success');
  });
}

/**
 * Menghapus satu foto dari galeri foto kegiatan tertentu (dengan konfirmasi).
 * @param {number} actIdx - index kegiatan
 * @param {number} photoIdx - index foto di dalam kegiatan tsb
 */
async function removeActivityPhoto(actIdx, photoIdx) {
  if (!confirm('Hapus foto ini?')) return;
  data.activities[actIdx].photos.splice(photoIdx, 1);
  await saveData();
  renderActivities();
  renderActivitiesEditor();
  showToast('Foto dihapus', 'success');
}

// =====================
// SETTINGS PANEL (dilindungi password client-side)
// =====================
const pwModal = document.getElementById('pwModal');
const pwInput = document.getElementById('pwInput');
const pwErr = document.getElementById('pwErr');
const settingsPanel = document.getElementById('settingsPanel');
const settingsOverlay = document.getElementById('settingsOverlay');

/** Menampilkan modal password sebelum masuk ke panel Settings. */
async function openPwModal() {
  if (adminSession) {
    openSettings();
    return;
  }
  pwModal.classList.add('open');
  const { data: sessionData } = await supabase.auth.getSession();
  const emailInput = document.getElementById('pwEmail');
  if (sessionData?.session?.user?.email && emailInput) emailInput.value = sessionData.session.user.email;
  setTimeout(() => document.getElementById('pwEmail')?.focus(), 200);
}

/** Menutup modal password & reset input/pesan error. */
function closePwModal() {
  pwModal.classList.remove('open');
  pwInput.value = '';
  pwErr.classList.remove('show');
}

// Klik di area gelap luar kotak modal = tutup modal (klik di dalam kotak tidak menutup)
pwModal.addEventListener('click', (e) => {
  if (e.target === pwModal) closePwModal();
});

/** Membuka autentikasi admin Supabase lalu membuka Settings jika berhasil. */
async function tryUnlock() {
  const email = document.getElementById('pwEmail')?.value.trim();
  const password = pwInput.value;
  pwErr.classList.remove('show');
  if (!email || !password) {
    pwErr.textContent = 'Email dan password wajib diisi.';
    pwErr.classList.add('show');
    return;
  }
  try {
    adminSession = await signIn(email, password);
    cloudReady = true;
    const remote = await loadCloud(defaultData);
    if (!remote) {
      data = loadLocal(defaultData, sanitizeDataObject) || clone(defaultData);
      await saveCloud(data);
      data = (await loadCloud(defaultData)) || data;
      saveLocal(data);
      applyData();
    }
    closePwModal();
    openSettings();
    showToast('Login admin berhasil ✓', 'success');
  } catch (error) {
    console.error(error);
    pwErr.textContent = 'Email atau password salah. Periksa akun Supabase Anda.';
    pwErr.classList.add('show');
    pwInput.value = '';
    pwInput.focus();
  }
}

// Kontrol keyboard: Escape menutup modal password/panel Settings/galeri (mana yang lagi terbuka),
// dan panah kiri/kanan menavigasi galeri foto saat sedang terbuka
document.addEventListener('keydown', (e) => {
  const galleryEl = document.getElementById('galleryModal');
  if (e.key === 'Escape') {
    if (pwModal.classList.contains('open')) closePwModal();
    else if (galleryEl.classList.contains('open')) closeGallery();
    else if (settingsPanel.classList.contains('open')) closeSettings();
    return;
  }
  if (galleryEl.classList.contains('open')) {
    if (e.key === 'ArrowLeft') galleryPrev();
    else if (e.key === 'ArrowRight') galleryNext();
  }
});

/** Membuka panel Settings & mengisi semua field form dari state `data` saat ini. */
async function logoutAdmin() {
  try {
    await signOut();
    adminSession = null;
    closeSettings();
    showToast('Logout berhasil', 'success');
  } catch (error) {
    showToast(`Logout gagal: ${error.message}`, 'error');
  }
}

function openSettings() {
  // Populate fields
  document.getElementById('sBrandName').value = data.profile.brandName;
  document.getElementById('sBrandMark').value = data.profile.brandMark;
  document.getElementById('sHeroAccent').value = data.profile.heroAccent;
  document.getElementById('sHeroLine2').value = data.profile.heroLine2;
  document.getElementById('sHeroLine3').value = data.profile.heroLine3;
  document.getElementById('sHeroLead').value = data.profile.heroLead;
  document.getElementById('sEmail').value = data.profile.email;

  document.getElementById('sAboutHi').value = data.about.hi;
  document.getElementById('sAboutHeading').value = data.about.heading;
  document.getElementById('sAboutP1').value = data.about.p1;
  document.getElementById('sAboutP2').value = data.about.p2;
  document.getElementById('sFactName').value = data.about.factName;
  document.getElementById('sFactStatus').value = data.about.factStatus;
  document.getElementById('sFactLocation').value = data.about.factLocation;
  document.getElementById('sFactInterest').value = data.about.factInterest;
  document.getElementById('sQuoteAuthor').value = data.about.quoteAuthor;

  document.getElementById('sLegalName').value = data.profile.legalName;
  document.getElementById('sFooterCredit').value = data.profile.footerCredit;
  // Social URLs — cari tiap platform dari array data.socials berdasarkan key-nya
  const socialByKey = {};
  data.socials.forEach(s => { socialByKey[s.key] = s.url; });
  document.getElementById('sSocialInstagram').value = socialByKey.instagram || '';
  document.getElementById('sSocialGithub').value = socialByKey.github || '';
  document.getElementById('sSocialLinkedin').value = socialByKey.linkedin || '';
  document.getElementById('sSocialTwitter').value = socialByKey.twitter || '';
  document.getElementById('sSocialDribbble').value = socialByKey.dribbble || '';

  renderProfilePhotoEditor();
  renderSkillsEditor();
  renderActivitiesEditor();
  renderEducationEditor();
  renderAchievementsEditor();
  renderProjectsEditor();

  const pwHint = document.getElementById('currentPwHint');
  if (pwHint) {
    pwHint.textContent = adminSession?.user?.email
      ? `Login sebagai ${adminSession.user.email}.`
      : 'Autentikasi dikelola oleh Supabase Auth.';
  }

  settingsPanel.classList.add('open');
  settingsOverlay.classList.add('open');
}

/** Menutup panel Settings tanpa menyimpan perubahan (perubahan hanya disimpan lewat saveSettings). */
function closeSettings() {
  settingsPanel.classList.remove('open');
  settingsOverlay.classList.remove('open');
}

/** Berpindah tab di panel Settings (Profil/Tentang/Kegiatan/Pendidikan/Keamanan). @param {string} tab - dataset.tab tujuan */
function switchTab(tab) {
  document.querySelectorAll('.settings-tabs button').forEach(b => {
    b.classList.toggle('active', b.dataset.tab === tab);
  });
  document.querySelectorAll('.settings-section').forEach(s => {
    s.classList.toggle('active', s.dataset.section === tab);
  });
}

/** Membangun form edit untuk tiap item di data.activities (dipanggil tiap kali panel Settings dibuka). */
/** Membangun form edit untuk data.activities. Jumlah kegiatan BEBAS (tambah/hapus lewat tombol). */
function renderActivitiesEditor() {
  const editor = document.getElementById('activitiesEditor');
  if (data.activities.length === 0) {
    editor.innerHTML = '<p class="hint">Belum ada kegiatan. Klik tombol di bawah untuk menambahkan.</p>';
    return;
  }
  editor.innerHTML = data.activities.map((a, i) => `
    <div class="activity-edit">
      <h5><span class="num">${i+1}</span> Kegiatan ${i+1}</h5>
      <div class="field">
        <label>Role / Kategori</label>
        <input type="text" data-field="role" data-idx="${i}" value="${escapeHtml(a.role)}"/>
      </div>
      <div class="field">
        <label>Judul</label>
        <input type="text" data-field="title" data-idx="${i}" value="${escapeHtml(a.title)}"/>
      </div>
      <div class="field">
        <label>Organisasi</label>
        <input type="text" data-field="org" data-idx="${i}" value="${escapeHtml(a.org)}"/>
      </div>
      <div class="field">
        <label>Deskripsi</label>
        <textarea data-field="desc" data-idx="${i}" rows="3">${escapeHtml(a.desc)}</textarea>
      </div>
      <div class="field">
        <label>Periode</label>
        <input type="text" data-field="period" data-idx="${i}" value="${escapeHtml(a.period)}"/>
      </div>
      <div class="field">
        <label>Galeri Foto Kegiatan</label>
        ${a.photos.length === 0
          ? '<p class="hint">Belum ada foto.</p>'
          : `<div class="photo-list">${a.photos.map((p, pi) => `
            <div class="photo-list-item">
              <img class="thumb" src="${escapeHtml(p.src)}" alt="Foto ${pi+1}"/>
              <div class="photo-list-body">
                <input type="text" placeholder="Caption foto (opsional)" data-act-photo-caption data-act-idx="${i}" data-photo-idx="${pi}" value="${escapeHtml(p.caption)}"/>
                <div class="photo-list-actions">
                  <button type="button" class="danger" onclick="removeActivityPhoto(${i}, ${pi})">🗑 Hapus Foto Ini</button>
                </div>
              </div>
            </div>
          `).join('')}</div>`}
        <input type="file" id="actPhotoAddInput${i}" class="hidden-input" accept="image/*" onchange="handleActivityPhotoAdd(event, ${i})"/>
        <button type="button" class="add-photo-btn" onclick="document.getElementById('actPhotoAddInput${i}').click()">+ Tambah Foto</button>
      </div>
      <button type="button" class="btn btn-ghost" style="padding:8px 16px; font-size:13px; margin-top:6px;" onclick="removeActivity(${i})">🗑 Hapus Kegiatan Ini</button>
    </div>
  `).join('');
}

/** Menambah kegiatan baru (kosong, siap diisi) di akhir daftar. Tersimpan langsung. */
function addActivity() {
  data.activities.push({ role: '', title: 'Kegiatan Baru', org: '', desc: '', period: '', photos: [] });
  saveData();
  renderActivities();
  renderActivitiesEditor();
  showToast('Kegiatan baru ditambahkan ✓', 'success');
}

/** Menghapus satu kegiatan beserta semua fotonya (dengan konfirmasi). @param {number} idx */
function removeActivity(idx) {
  if (!confirm('Hapus kegiatan ini beserta semua fotonya?')) return;
  data.activities.splice(idx, 1);
  saveData();
  renderActivities();
  renderActivitiesEditor();
  showToast('Kegiatan dihapus', 'success');
}

/** Membangun form edit untuk tiap item di data.education. Jumlah pendidikan BEBAS (tambah/hapus lewat tombol). */
function renderEducationEditor() {
  const editor = document.getElementById('educationEditor');
  if (data.education.length === 0) {
    editor.innerHTML = '<p class="hint">Belum ada riwayat pendidikan. Klik tombol di bawah untuk menambahkan.</p>';
    return;
  }
  editor.innerHTML = data.education.map((e, i) => `
    <div class="activity-edit">
      <h5><span class="num">${i+1}</span> Pendidikan ${i+1}</h5>
      <div class="field">
        <label>Periode (tahun)</label>
        <input type="text" data-edu-field="year" data-idx="${i}" value="${escapeHtml(e.year)}"/>
      </div>
      <div class="field">
        <label>Nama Sekolah</label>
        <input type="text" data-edu-field="school" data-idx="${i}" value="${escapeHtml(e.school)}"/>
      </div>
      <div class="field">
        <label>Lokasi / Jurusan</label>
        <input type="text" data-edu-field="location" data-idx="${i}" value="${escapeHtml(e.location)}"/>
      </div>
      <div class="field">
        <label>Deskripsi</label>
        <textarea data-edu-field="desc" data-idx="${i}" rows="3">${escapeHtml(e.desc)}</textarea>
      </div>
      <div class="field">
        <label>Tags (pisahkan dengan koma)</label>
        <input type="text" data-edu-field="tags" data-idx="${i}" value="${escapeHtml((e.tags || []).join(', '))}"/>
      </div>
      <button type="button" class="btn btn-ghost" style="padding:8px 16px; font-size:13px; margin-top:6px;" onclick="removeEducation(${i})">🗑 Hapus Pendidikan Ini</button>
    </div>
  `).join('');
}

/** Menambah riwayat pendidikan baru (kosong, siap diisi) di akhir daftar. Tersimpan langsung. */
function addEducation() {
  data.education.push({ year: '', school: 'Sekolah Baru', location: '', desc: '', tags: [] });
  saveData();
  renderEducation();
  renderEducationEditor();
  showToast('Pendidikan baru ditambahkan ✓', 'success');
}

/** Menghapus satu riwayat pendidikan (dengan konfirmasi). @param {number} idx */
function removeEducation(idx) {
  if (!confirm('Hapus riwayat pendidikan ini?')) return;
  data.education.splice(idx, 1);
  saveData();
  renderEducation();
  renderEducationEditor();
  showToast('Pendidikan dihapus', 'success');
}

/**
 * Membangun form edit untuk data.achievements. Berbeda dari activities/education,
 * di sini jumlah item BEBAS — bisa ditambah lewat addAchievement() dan dihapus
 * lewat tombol per-item yang memanggil removeAchievement(idx).
 */
function renderAchievementsEditor() {
  const editor = document.getElementById('achievementsEditor');
  if (!editor) return;
  if (data.achievements.length === 0) {
    editor.innerHTML = '<p class="hint">Belum ada pencapaian. Klik tombol di bawah untuk menambahkan.</p>';
    return;
  }
  editor.innerHTML = data.achievements.map((a, i) => `
    <div class="activity-edit">
      <h5><span class="num">${i+1}</span> Pencapaian ${i+1}</h5>
      <div class="field">
        <label>Ikon</label>
        <select data-ach-field="icon" data-idx="${i}">
          ${Object.keys(achievementIcons).map(key =>
            `<option value="${key}" ${a.icon === key ? 'selected' : ''}>${achievementIconLabels[key] || key}</option>`
          ).join('')}
        </select>
      </div>
      <div class="field">
        <label>Judul</label>
        <input type="text" data-ach-field="title" data-idx="${i}" value="${escapeHtml(a.title)}"/>
      </div>
      <div class="field">
        <label>Sub-teks</label>
        <input type="text" data-ach-field="subtitle" data-idx="${i}" value="${escapeHtml(a.subtitle)}"/>
      </div>
      <button type="button" class="btn btn-ghost" style="padding:8px 16px; font-size:13px;" onclick="removeAchievement(${i})">🗑 Hapus Pencapaian Ini</button>
    </div>
  `).join('');
}

/** Menambah satu item pencapaian baru (kosong, siap diisi) di akhir daftar. Tersimpan langsung. */
function addAchievement() {
  data.achievements.push({ icon: 'medal', title: 'Pencapaian Baru', subtitle: '' });
  saveData();
  renderAchievementsEditor(); // refresh form editor di Settings
  renderAchievements();       // refresh tampilan kartu di homepage
  showToast('Pencapaian baru ditambahkan ✓', 'success');
}

/**
 * Menghapus satu item pencapaian (dengan konfirmasi, karena aksi ini permanen). Tersimpan langsung.
 * @param {number} idx - index item di data.achievements
 */
function removeAchievement(idx) {
  if (!confirm('Hapus pencapaian ini?')) return;
  data.achievements.splice(idx, 1);
  saveData();
  renderAchievementsEditor();
  renderAchievements();
  showToast('Pencapaian dihapus', 'success');
}

/**
 * Membangun form edit untuk data.skills. Sama seperti achievements: jumlah item BEBAS —
 * bisa ditambah lewat addSkill() dan dihapus lewat tombol per-item (removeSkill(idx)).
 */
function renderSkillsEditor() {
  const editor = document.getElementById('skillsEditor');
  if (!editor) return;
  if (data.skills.length === 0) {
    editor.innerHTML = '<p class="hint">Belum ada skill. Klik tombol di bawah untuk menambahkan.</p>';
    return;
  }
  editor.innerHTML = data.skills.map((s, i) => `
    <div class="activity-edit">
      <h5><span class="num">${i+1}</span> Skill ${i+1}</h5>
      <div class="field">
        <label>Ikon</label>
        <select data-skill-field="icon" data-idx="${i}">
          ${Object.keys(skillIcons).map(key =>
            `<option value="${key}" ${s.icon === key ? 'selected' : ''}>${skillIconLabels[key] || key}</option>`
          ).join('')}
        </select>
      </div>
      <div class="field">
        <label>Nama Skill</label>
        <input type="text" data-skill-field="title" data-idx="${i}" value="${escapeHtml(s.title)}"/>
      </div>
      <div class="field">
        <label>Sub-teks</label>
        <input type="text" data-skill-field="subtitle" data-idx="${i}" value="${escapeHtml(s.subtitle)}"/>
      </div>
      <button type="button" class="btn btn-ghost" style="padding:8px 16px; font-size:13px;" onclick="removeSkill(${i})">🗑 Hapus Skill Ini</button>
    </div>
  `).join('');
}

/** Menambah satu skill baru (kosong, siap diisi) di akhir daftar. Tersimpan langsung. */
function addSkill() {
  data.skills.push({ icon: 'design', title: 'Skill Baru', subtitle: '' });
  saveData();
  renderSkillsEditor(); // refresh form editor di Settings
  renderSkills();       // refresh tampilan kartu di homepage
  showToast('Skill baru ditambahkan ✓', 'success');
}

/**
 * Menghapus satu skill (dengan konfirmasi, karena aksi ini permanen). Tersimpan langsung.
 * @param {number} idx - index item di data.skills
 */
function removeSkill(idx) {
  if (!confirm('Hapus skill ini?')) return;
  data.skills.splice(idx, 1);
  saveData();
  renderSkillsEditor();
  renderSkills();
  showToast('Skill dihapus', 'success');
}

/**
 * Membangun form edit untuk data.projects. Jumlah proyek BEBAS (tambah/hapus lewat tombol).
 * Field 'link' opsional — kalau diisi, kartu proyeknya jadi bisa disentuh di homepage.
 */
function renderProjectsEditor() {
  const editor = document.getElementById('projectsEditor');
  if (!editor) return;
  if (data.projects.length === 0) {
    editor.innerHTML = '<p class="hint">Belum ada proyek. Klik tombol di bawah untuk menambahkan.</p>';
    return;
  }
  editor.innerHTML = data.projects.map((p, i) => `
    <div class="activity-edit">
      <h5><span class="num">${i+1}</span> Proyek ${i+1}</h5>
      <div class="field">
        <label>Emoji (ikon kartu)</label>
        <input type="text" data-proj-field="emoji" data-idx="${i}" value="${escapeHtml(p.emoji)}" maxlength="8"/>
      </div>
      <div class="field">
        <label>Label Kategori</label>
        <input type="text" data-proj-field="tag" data-idx="${i}" value="${escapeHtml(p.tag)}" placeholder="mis. UI/UX, Branding, Web"/>
      </div>
      <div class="field">
        <label>Judul Proyek</label>
        <input type="text" data-proj-field="title" data-idx="${i}" value="${escapeHtml(p.title)}"/>
      </div>
      <div class="field">
        <label>Deskripsi</label>
        <textarea data-proj-field="desc" data-idx="${i}" rows="3">${escapeHtml(p.desc)}</textarea>
      </div>
      <div class="field">
        <label>Tags (pisahkan dengan koma)</label>
        <input type="text" data-proj-field="tags" data-idx="${i}" value="${escapeHtml((p.tags || []).join(', '))}"/>
      </div>
      <div class="field">
        <label>Link (opsional — demo, repo, Figma, dll)</label>
        <input type="text" data-proj-field="link" data-idx="${i}" value="${escapeHtml(p.link)}" placeholder="https://..."/>
      </div>
      <button type="button" class="btn btn-ghost" style="padding:8px 16px; font-size:13px; margin-top:6px;" onclick="removeProject(${i})">🗑 Hapus Proyek Ini</button>
    </div>
  `).join('');
}

/** Menambah proyek baru (kosong, siap diisi) di akhir daftar. Tersimpan langsung. */
function addProject() {
  data.projects.push({ emoji: '📁', tag: '', title: 'Proyek Baru', desc: '', tags: [], link: '' });
  saveData();
  renderProjects();
  renderProjectsEditor();
  showToast('Proyek baru ditambahkan ✓', 'success');
}

/** Menghapus satu proyek (dengan konfirmasi). @param {number} idx */
function removeProject(idx) {
  if (!confirm('Hapus proyek ini?')) return;
  data.projects.splice(idx, 1);
  saveData();
  renderProjects();
  renderProjectsEditor();
  showToast('Proyek dihapus', 'success');
}

/**
 * Membaca semua field form di panel Settings, menuliskannya ke `data`,
 * lalu menyimpan ke localStorage dan menerapkan ke halaman.
 * Ada validasi khusus untuk password baru sebelum data disimpan.
 */
async function saveSettings() {
  // Profile
  data.profile.brandName = document.getElementById('sBrandName').value || 'Khanza';
  data.profile.brandMark = (document.getElementById('sBrandMark').value || 'K').charAt(0).toUpperCase();
  data.profile.heroAccent = document.getElementById('sHeroAccent').value || 'Athaa';
  data.profile.heroLine2 = document.getElementById('sHeroLine2').value;
  data.profile.heroLine3 = document.getElementById('sHeroLine3').value;
  data.profile.heroLead = document.getElementById('sHeroLead').value;
  data.profile.email = document.getElementById('sEmail').value || 'athaa.maharani@email.com';

  // Caption foto profil (upload/ganti/hapus fotonya sendiri sudah langsung tersimpan
  // saat tombolnya diklik — di sini cuma menyimpan teks caption yang diketik user)
  document.querySelectorAll('#profilePhotoEditor [data-profile-photo-caption]').forEach(el => {
    const idx = parseInt(el.dataset.idx);
    if (data.profile.photos[idx]) data.profile.photos[idx].caption = el.value;
  });

  // About
  data.about.hi = document.getElementById('sAboutHi').value;
  data.about.heading = document.getElementById('sAboutHeading').value;
  data.about.p1 = document.getElementById('sAboutP1').value;
  data.about.p2 = document.getElementById('sAboutP2').value;
  data.about.factName = document.getElementById('sFactName').value;
  data.about.factStatus = document.getElementById('sFactStatus').value;
  data.about.factLocation = document.getElementById('sFactLocation').value;
  data.about.factInterest = document.getElementById('sFactInterest').value;
  data.about.quoteAuthor = document.getElementById('sQuoteAuthor').value || 'Khanza';

  // Activities text fields
  document.querySelectorAll('#activitiesEditor [data-field]').forEach(el => {
    const idx = parseInt(el.dataset.idx);
    const field = el.dataset.field;
    if (data.activities[idx]) data.activities[idx][field] = el.value;
  });

  // Caption foto kegiatan (upload/hapus fotonya sendiri sudah langsung tersimpan
  // saat tombolnya diklik — di sini cuma menyimpan teks caption yang diketik user)
  document.querySelectorAll('#activitiesEditor [data-act-photo-caption]').forEach(el => {
    const actIdx = parseInt(el.dataset.actIdx);
    const photoIdx = parseInt(el.dataset.photoIdx);
    if (data.activities[actIdx] && data.activities[actIdx].photos[photoIdx]) {
      data.activities[actIdx].photos[photoIdx].caption = el.value;
    }
  });

  // Education text fields
  document.querySelectorAll('#educationEditor [data-edu-field]').forEach(el => {
    const idx = parseInt(el.dataset.idx);
    const field = el.dataset.eduField;
    if (data.education[idx]) {
      if (field === 'tags') {
        data.education[idx].tags = el.value.split(',').map(t => t.trim()).filter(Boolean);
      } else {
        data.education[idx][field] = el.value;
      }
    }
  });

  // Achievements text/icon fields (jumlah item sendiri sudah dikelola langsung oleh
  // addAchievement()/removeAchievement() saat tombolnya diklik, di sini cuma update isinya)
  document.querySelectorAll('#achievementsEditor [data-ach-field]').forEach(el => {
    const idx = parseInt(el.dataset.idx);
    const field = el.dataset.achField;
    if (data.achievements[idx]) data.achievements[idx][field] = el.value;
  });

  // Skills text/icon fields (jumlah item sendiri sudah dikelola langsung oleh
  // addSkill()/removeSkill() saat tombolnya diklik, di sini cuma update isinya)
  document.querySelectorAll('#skillsEditor [data-skill-field]').forEach(el => {
    const idx = parseInt(el.dataset.idx);
    const field = el.dataset.skillField;
    if (data.skills[idx]) data.skills[idx][field] = el.value;
  });

  // Projects text fields (jumlah item sendiri sudah dikelola langsung oleh
  // addProject()/removeProject() saat tombolnya diklik, di sini cuma update isinya)
  document.querySelectorAll('#projectsEditor [data-proj-field]').forEach(el => {
    const idx = parseInt(el.dataset.idx);
    const field = el.dataset.projField;
    if (!data.projects[idx]) return;
    if (field === 'tags') {
      data.projects[idx].tags = el.value.split(',').map(t => t.trim()).filter(Boolean);
    } else {
      data.projects[idx][field] = el.value;
    }
  });

  // Sosial media — platform-nya tetap 5, cuma URL-nya yang diupdate dari field masing-masing
  const socialInputs = {
    instagram: document.getElementById('sSocialInstagram').value,
    github: document.getElementById('sSocialGithub').value,
    linkedin: document.getElementById('sSocialLinkedin').value,
    twitter: document.getElementById('sSocialTwitter').value,
    dribbble: document.getElementById('sSocialDribbble').value
  };
  data.socials.forEach(s => { s.url = socialInputs[s.key] || ''; });

  // Footer: nama lengkap untuk hak cipta & kalimat kecil di bawah
  data.profile.legalName = document.getElementById('sLegalName').value || defaultData.profile.legalName;
  data.profile.footerCredit = document.getElementById('sFooterCredit').value;

  const ok = await saveData();
  if (!ok) return;
  applyData();
  closeSettings();
  showToast('Settings tersimpan di Supabase ✓', 'success');
}

/** Menghapus seluruh data tersimpan di localStorage dan mengembalikan halaman ke kondisi default (dengan konfirmasi). */
async function resetAll() {
  if (!confirm('Reset semua data cloud ke kosong? Semua teks dan foto akan dihapus.')) return;
  if (!adminSession) {
    showToast('Login admin diperlukan.', 'error');
    return;
  }
  try {
    await resetCloud();
    clearLocal();
    data = clone(defaultData);
    applyData();
    closeSettings();
    showToast('Semua data cloud direset ✓', 'success');
  } catch (error) {
    console.error(error);
    showToast(`Reset gagal: ${error.message}`, 'error');
  }
}

// =====================
// EXPORT / IMPORT DATA (backup, transfer antar browser, atau bahan "bake-in" ke versi publik)
// =====================
/**
 * Mendownload seluruh isi `data` sebagai file .json. Password SENGAJA tidak diikutkan
 * supaya kalau file ini dibagikan/dikirim ke orang lain, password tidak ikut bocor.
 */
function exportData() {
  // Salin data lalu buang field password sebelum diekspor
  const exportable = JSON.parse(JSON.stringify(data));

  const json = JSON.stringify(exportable, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  const a = document.createElement('a');
  a.href = url;
  a.download = `portfolio-data-${today}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  showToast('Data berhasil di-export ✓', 'success');
}

/**
 * Membaca file .json yang dipilih user, memvalidasinya lewat sanitizeDataObject()
 * (jadi kalau isinya rusak/aneh/jahat tetap aman), lalu menimpa seluruh `data` saat ini.
 * Password perangkat ini SENGAJA dipertahankan (tidak ikut ditimpa oleh file import),
 * karena file export tidak pernah menyertakan password.
 */
async function importData(event) {
  const file = event.target.files[0];
  event.target.value = '';
  if (!file) return;
  if (!adminSession) {
    showToast('Login admin diperlukan.', 'error');
    return;
  }
  if (!confirm('Import akan MENIMPA semua data cloud yang sedang ditampilkan. Lanjutkan?')) return;

  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const parsed = JSON.parse(reader.result);
      const sanitized = sanitizeDataObject(parsed, defaultData);
      data = sanitized;
      const ok = await saveData();
      if (!ok) return;
      applyData();
      openSettings();
      showToast('Data berhasil di-import ke Supabase ✓', 'success');
    } catch (e) {
      console.error(e);
      showToast('Import gagal — periksa file JSON dan koneksi Supabase.', 'error');
    }
  };
  reader.onerror = () => showToast('Gagal membaca file', 'error');
  reader.readAsText(file);
}

// =====================
// TOAST
// =====================
/**
 * Menampilkan notifikasi kecil (toast) sekilas di layar.
 * @param {string} msg - pesan yang ditampilkan
 * @param {'success'|'error'|''} type - menentukan warna toast
 */
function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast show ' + type;
  setTimeout(() => t.classList.remove('show'), 2500);
}

// =====================
// NAV, SCROLL, MOBILE MENU
// =====================
const nav = document.getElementById('nav');
const totop = document.getElementById('totop');
// Ubah tampilan navbar (jadi blur/solid) & tampilkan tombol "back to top" setelah scroll > 20px
window.addEventListener('scroll', () => {
  if (window.scrollY > 20) {
    nav.classList.add('scrolled');
    totop.classList.add('show');
  } else {
    nav.classList.remove('scrolled');
    totop.classList.remove('show');
  }
});

// Smooth-scroll untuk semua link anchor (#section) + otomatis menutup mobile menu setelah diklik
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', (e) => {
    const id = a.getAttribute('href');
    if (id.length > 1) {
      e.preventDefault();
      const target = document.querySelector(id);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        document.getElementById('mobileMenu').classList.remove('open');
        document.getElementById('menuBackdrop').classList.remove('open');
      }
    }
  });
});

totop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

// Buka/tutup menu mobile (hamburger) beserta backdrop gelapnya
const menuOpen = document.getElementById('menuOpen');
const menuClose = document.getElementById('menuClose');
const mobileMenu = document.getElementById('mobileMenu');
const menuBackdrop = document.getElementById('menuBackdrop');
menuOpen.addEventListener('click', () => {
  mobileMenu.classList.add('open');
  menuBackdrop.classList.add('open');
});
menuClose.addEventListener('click', () => {
  mobileMenu.classList.remove('open');
  menuBackdrop.classList.remove('open');
});
menuBackdrop.addEventListener('click', () => {
  mobileMenu.classList.remove('open');
  menuBackdrop.classList.remove('open');
});

// Reveal on scroll — elemen ber-class .reveal muncul dengan animasi fade+slide
// saat 12% bagiannya masuk viewport, lalu observer-nya dilepas (animasi cukup sekali).
// Elemen yang dibuat ulang secara dinamis (activities, education) di-observe lagi
// secara manual di renderActivities()/renderEducation() karena observer ini
// hanya menjangkau elemen yang ada saat halaman pertama kali dimuat.
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('in');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });
document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));

// =====================
// INIT — local cache tampil cepat, lalu sinkronisasi Supabase.
// =====================
applyData();

async function bootstrapCloud() {
  try {
    adminSession = await getSession();
    const remote = await loadCloud(defaultData);
    if (remote) {
      data = remote;
      saveLocal(data);
      applyData();
      cloudReady = true;
      return;
    }

    if (adminSession) {
      const localData = loadLocal(defaultData, sanitizeDataObject);
      data = localData || clone(defaultData);
      await saveCloud(data);
      data = (await loadCloud(defaultData)) || data;
      saveLocal(data);
      applyData();
      cloudReady = true;
      showToast('Data awal berhasil disinkronkan ke Supabase ✓', 'success');
    } else {
      cloudReady = false;
    }
  } catch (error) {
    console.error('Supabase bootstrap failed:', error);
    cloudReady = false;
    showToast('Supabase belum dapat diakses. Mode lokal sementara aktif.', 'error');
  }
}

await bootstrapCloud();

Object.assign(window, {
  addAchievement, addActivity, addEducation, addProject, addSkill,
  cancelCrop, closeGallery, closePwModal, closeSettings, confirmCrop,
  exportData, galleryNext, galleryPrev, openActivityGallery, openProfileGallery,
  openPwModal, removeAchievement, removeActivity, removeActivityPhoto,
  removeEducation, removeProfilePhoto, removeProject, removeSkill, resetAll,
  saveSettings, switchTab, triggerReplaceProfilePhoto, tryUnlock,
  handleActivityPhotoAdd, handleProfilePhotoAdd, handleProfilePhotoReplace,
  importData, onCropZoomInput, logoutAdmin
});
