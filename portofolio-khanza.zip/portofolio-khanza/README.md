# Khanza Portfolio — Supabase Edition

Modular portfolio based on `index-6.html`, migrated to Supabase Database, Storage and Auth.

## Architecture

GitHub → Vercel → Supabase

- PostgreSQL: portfolio data
- Storage bucket `portfolio-photos`: photos
- Supabase Auth: admin login
- RLS: public read + admin-only writes
- localStorage: cache/fallback only

## Supabase setup

1. The project URL and publishable key are already configured in `js/config/supabase.js`.
2. Bucket: `portfolio-photos`, **Public = ON**.
3. Run `supabase/schema.sql` if you need to recreate the database.
4. Run `supabase/seed.sql` once to populate the current content from `index-6.html`.
5. The admin UID is `0f793c54-458e-4dc1-b674-ab9f63b70388`.

Never put a `service_role`/secret key in this repository.

## Admin

Open Settings → Login Admin → use the email/password created in Supabase Authentication.

The old client-side `khanza` password is removed from the application.

## Photos

Photo flow:
Choose → crop → compress → Supabase Storage → public URL → `photos` table.

## Deploy

Push this repository to GitHub, then import the repository into Vercel. This is a static frontend and does not require a custom server.

`legacy/index-6.html` is the original monolithic backup.
